package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Cliente opcional de IA via API compatível com OpenAI. Nunca contém uma chave embutida. */
class AegisAiClient(context: Context) {
    private val prefs = context.getSharedPreferences("aegis_ai_settings", Context.MODE_PRIVATE)

    fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()

    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_API, key.trim()).apply()
    }

    fun clearApiKey() { prefs.edit().remove(KEY_API).apply() }

    fun getApiKey(): String? = prefs.getString(KEY_API, null)

    fun ask(userText: String, memories: List<String>, history: List<Pair<String, String>> = emptyList()): String {
        val key = getApiKey()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("A IA ainda não foi configurada. Toque em ‘Configurar IA’ e adicione sua chave de API.")
        val connection = (URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val memoryText = if (memories.isEmpty()) "Nenhuma memória pessoal foi salva." else memories.joinToString("\n") { "- $it" }
            val systemPrompt = "Você é Aegis Nexus, assistente pessoal para Android. Responda sempre em português brasileiro, com tom sereno, inteligente, direto, empático e lógico, inspirado em um assistente futurista. Não alegue executar ações no celular que não foram implementadas. Use as memórias fornecidas apenas quando forem relevantes e não invente lembranças.\nMemórias que o usuário autorizou salvar neste aparelho:\n$memoryText"
            val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
            history.takeLast(10).forEach { (role, content) ->
                if (role == "user" || role == "assistant") {
                    messages.put(JSONObject().put("role", role).put("content", content))
                }
            }
            messages.put(JSONObject().put("role", "user").put("content", userText))
            val body = JSONObject()
                .put("model", "gpt-4o-mini")
                .put("messages", messages)
                .put("temperature", 0.7)
                .put("max_tokens", 450)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException(when (code) {
                    401 -> "A chave de API foi recusada. Confira a chave nas configurações da IA."
                    429 -> "A API atingiu o limite ou está sem crédito disponível. Confira sua conta de API."
                    else -> "A API retornou erro HTTP $code${detail?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "."}"
                })
            }
            val content = JSONObject(response).optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")?.trim()
            return content?.takeIf { it.isNotBlank() } ?: "Recebi uma resposta vazia da IA. Tente novamente."
        } finally {
            connection.disconnect()
        }
    }

    companion object { private const val KEY_API = "openai_api_key" }
}
