package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray

/** Memória local e explícita: só salva quando o usuário pede para lembrar. */
class AegisMemory(context: Context) {
    private val prefs = context.getSharedPreferences("aegis_personal_memory", Context.MODE_PRIVATE)

    @Synchronized
    fun remember(note: String): Boolean {
        val clean = note.trim().take(300)
        if (clean.isBlank()) return false
        val items = readAll().toMutableList()
        if (items.none { it.equals(clean, ignoreCase = true) }) items.add(clean)
        val json = JSONArray()
        items.takeLast(100).forEach { json.put(it) }
        prefs.edit().putString(KEY_ITEMS, json.toString()).apply()
        return true
    }

    @Synchronized
    fun all(): List<String> = readAll()

    @Synchronized
    fun clear() { prefs.edit().remove(KEY_ITEMS).apply() }

    private fun readAll(): List<String> {
        val raw = prefs.getString(KEY_ITEMS, "[]") ?: "[]"
        return try {
            val json = JSONArray(raw)
            (0 until json.length()).mapNotNull { json.optString(it).takeIf(String::isNotBlank) }
        } catch (_: Exception) { emptyList() }
    }

    companion object { private const val KEY_ITEMS = "items" }
}
