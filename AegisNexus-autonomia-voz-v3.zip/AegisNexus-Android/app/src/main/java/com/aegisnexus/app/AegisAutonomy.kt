package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Base local de autonomia: objetivos explícitos, estado persistente e sugestões limitadas. */
class AegisAutonomy(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aegis_autonomy", Context.MODE_PRIVATE)

    @Synchronized fun addGoal(goal: String): String {
        val clean = goal.trim().take(240)
        if (clean.isBlank()) return "Diga qual objetivo você quer registrar."
        val goals = getGoals().toMutableList()
        if (goals.none { it.equals(clean, ignoreCase = true) }) goals.add(clean)
        prefs.edit().putString(KEY_GOALS, JSONArray(goals.takeLast(50)).toString()).apply()
        return "Objetivo registrado: $clean. Vou mantê-lo na lista de prioridades e ajudar a planejar os próximos passos quando conversarmos."
    }

    @Synchronized fun getGoals(): List<String> {
        val raw = prefs.getString(KEY_GOALS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized fun clearGoals() { prefs.edit().remove(KEY_GOALS).apply() }

    fun handleCommand(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase()
        val prefixes = listOf("meu objetivo é", "meu objetivo e", "registre o objetivo", "registre como objetivo", "adicione o objetivo")
        val prefix = prefixes.firstOrNull { lower.startsWith(it) }
        if (prefix != null) return addGoal(text.drop(prefix.length).trim().trimStart(':', ',', ' '))
        if (listOf("quais são meus objetivos", "quais sao meus objetivos", "listar objetivos", "meus objetivos").any { lower.contains(it) }) {
            val goals = getGoals()
            return if (goals.isEmpty()) "Ainda não há objetivos registrados. Você pode dizer: meu objetivo é melhorar o Aegis Nexus."
            else "Seus objetivos registrados são: " + goals.mapIndexed { i, goal -> "${i + 1}: $goal" }.joinToString(". ")
        }
        if (listOf("apague meus objetivos", "limpe meus objetivos", "esqueça meus objetivos", "esqueca meus objetivos").any { lower.contains(it) }) {
            clearGoals(); return "A lista de objetivos foi apagada."
        }
        return null
    }

    /** Sugestão local, sem fingir que realizou ações ou observou dados externos. */
    fun proactiveOpening(): String {
        val goals = getGoals()
        return if (goals.isEmpty()) {
            "Bom dia. Minha base de autonomia está ativa. Ainda não tenho objetivos registrados; podemos começar definindo uma prioridade."
        } else {
            "Bom dia. Tenho ${goals.size} objetivo${if (goals.size == 1) "" else "s"} registrado${if (goals.size == 1) "" else "s"}. A prioridade atual pode ser: ${goals.first()}. Quer planejar o próximo passo?"
        }
    }

    fun planningPrompt(userInput: String): String {
        val goals = getGoals()
        val goalText = if (goals.isEmpty()) "Nenhum objetivo persistente registrado." else goals.mapIndexed { i, g -> "${i + 1}. $g" }.joinToString("\n")
        return "Objetivos persistentes do usuário:\n$goalText\n\nPedido atual: $userInput\n\nCrie um plano curto com próximos passos concretos. Diferencie sugestões de ações realmente executadas. Não alegue acesso a sensores, arquivos ou dados que não foram fornecidos."
    }

    companion object { private const val KEY_GOALS = "goals_json" }
}
