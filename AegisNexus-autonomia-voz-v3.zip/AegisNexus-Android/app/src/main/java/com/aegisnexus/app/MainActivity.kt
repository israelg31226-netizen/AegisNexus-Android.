package com.aegisnexus.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private var readyToSpeak = false
    private lateinit var replyEngine: AegisReplyEngine
    private lateinit var aiClient: AegisAiClient
    private lateinit var autonomy: AegisAutonomy
    private lateinit var wakeButton: Button
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 9, 24)
        window.navigationBarColor = android.graphics.Color.rgb(3, 9, 24)
        tts = TextToSpeech(this, this)
        replyEngine = AegisReplyEngine(applicationContext)
        aiClient = AegisAiClient(applicationContext)
        autonomy = AegisAutonomy(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(3, 9, 24))
        }
        val title = TextView(this).apply {
            text = "AEGIS NEXUS"
            textSize = 27f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
        }
        val subtitle = TextView(this).apply {
            text = "ASSISTENTE PESSOAL • PROTÓTIPO"
            textSize = 11f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(134, 164, 195))
        }
        val orb = OrbView(this)
        status = TextView(this).apply {
            text = "Sistema inicializado. Toque para falar."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 18, 8, 18)
        }
        talkButton = Button(this).apply {
            text = "FALAR COM A AEGIS"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { startListening() }
        }
        wakeButton = Button(this).apply {
            text = "ATIVAR ESCUTA: HEY NEXUS"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { toggleWakeListening() }
        }
        val configureAiButton = Button(this).apply {
            text = "CONFIGURAR IA"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { showAiConfiguration() }
        }
        val footer = TextView(this).apply {
            text = "VERSÃO 0.1 • VOZ LOCAL DO ANDROID"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(100, 129, 159))
            setPadding(0, 22, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(talkButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(wakeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(configureAiButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("aegis_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY NEXUS"
            status.postDelayed({ startListening() }, 700L)
        } else {
            val wakeEnabled = getSharedPreferences("aegis_autonomy", MODE_PRIVATE).getBoolean("wake_enabled", false)
            if (wakeEnabled) wakeButton.text = "DESATIVAR ESCUTA NEXUS"
            status.text = autonomy.proactiveOpening()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("aegis_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY NEXUS"
            status.text = "Nexus ativado. Pode falar."
            status.postDelayed({ startListening() }, 500L)
        }
    }

    private fun toggleWakeListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 43)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
            return
        }
        val prefs = getSharedPreferences("aegis_autonomy", MODE_PRIVATE)
        val active = prefs.getBoolean("wake_enabled", false)
        if (active) {
            startService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
            prefs.edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY NEXUS"
            status.text = "Escuta por palavra-chave desativada."
        } else {
            try {
                val serviceIntent = Intent(this, WakeWordService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                prefs.edit().putBoolean("wake_enabled", true).apply()
                wakeButton.text = "DESATIVAR ESCUTA NEXUS"
                status.text = "Escuta experimental ativa. Diga: Hey, bom dia, Nexus."
            } catch (e: Exception) {
                status.text = "Não foi possível iniciar a escuta: ${e.message ?: "erro do Android"}"
            }
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("pt", "BR"))
            readyToSpeak = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            if (readyToSpeak) tts?.setSpeechRate(0.96f)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Este aparelho não disponibilizou reconhecimento de voz."
            speak("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo…"; talkButton.text = "OUVINDO…" }
                override fun onBeginningOfSpeech() { status.text = "Pode continuar falando." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { talkButton.text = "FALAR COM A AEGIS"; status.text = "Processando sua fala…" }
                override fun onError(error: Int) { talkButton.text = "FALAR COM A AEGIS"; status.text = "Não consegui entender. Toque e tente novamente." }
                override fun onResults(results: Bundle?) {
                    talkButton.text = "FALAR COM A AEGIS"
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (words.isNullOrBlank()) { status.text = "Não recebi uma frase."; return }
                    val autonomyReply = autonomy.handleCommand(words)
                    if (autonomyReply != null) {
                        status.text = autonomyReply
                        speak(autonomyReply)
                    } else if (replyEngine.isMemoryCommand(words)) {
                        val reply = replyEngine.respond(words)
                        status.text = reply
                        speak(reply)
                    } else if (aiClient.hasApiKey()) {
                        status.text = "Aegis está pensando…"
                        talkButton.isEnabled = false
                        networkExecutor.execute {
                            val reply = try {
                                aiClient.ask(autonomy.planningPrompt(words), AegisMemory(applicationContext).all(), conversationHistory.toList())
                            } catch (e: Exception) {
                                e.message ?: "Não consegui acessar a IA agora. Verifique a internet e tente novamente."
                            }
                            runOnUiThread {
                                talkButton.isEnabled = true
                                conversationHistory.add("user" to words)
                                conversationHistory.add("assistant" to reply)
                                while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                                status.text = reply
                                speak(reply)
                            }
                        }
                    } else {
                        val reply = replyEngine.respond(words)
                        status.text = reply + " Para ativar conversa inteligente, toque em Configurar IA."
                        speak(reply + " Para ativar a conversa inteligente, configure a IA no botão abaixo.")
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Aegis")
            }
            sr.startListening(intent)
        }
    }

    private fun showAiConfiguration() {
        val input = EditText(this).apply {
            hint = "sk-…"
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(aiClient.getApiKey().orEmpty())
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 12, 40, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply {
                text = "A chave fica salva neste aparelho e é enviada à API da OpenAI para gerar respostas. O uso da API pode ser cobrado separadamente da assinatura do ChatGPT. Para um app distribuído ao público, o ideal é usar um servidor próprio em vez de guardar chaves no aplicativo."
                textSize = 12f
                setPadding(0, 12, 0, 0)
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Configurar conversa inteligente")
            .setView(layout)
            .setPositiveButton("Salvar chave") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isBlank()) {
                    Toast.makeText(this, "Informe uma chave de API válida.", Toast.LENGTH_LONG).show()
                } else {
                    aiClient.saveApiKey(key)
                    status.text = "IA configurada. Toque em Falar com a Aegis para conversar."
                    Toast.makeText(this, "Chave salva neste aparelho.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Apagar chave") { _, _ ->
                aiClient.clearApiKey()
                status.text = "Chave de IA apagada. A Aegis usará respostas locais."
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun speak(text: String) { if (readyToSpeak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aegis_reply") }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if ((requestCode == 42 || requestCode == 43 || requestCode == 44) && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == 42) startListening() else toggleWakeListening()
        } else if (requestCode == 42 || requestCode == 43) Toast.makeText(this, "Permita o microfone para usar a voz do Aegis Nexus.", Toast.LENGTH_LONG).show()
        else if (requestCode == 44) Toast.makeText(this, "Sem notificações, o aviso de ativação por voz pode não aparecer.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        networkExecutor.shutdownNow()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    private class OrbView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val cyan = android.graphics.Color.rgb(70, 225, 255)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val radius = (width.coerceAtMost(height) * 0.29f).coerceAtLeast(60f)
            phase += 0.025f
            paint.shader = RadialGradient(cx, cy, radius * 1.55f, intArrayOf(0x5538dfff, 0x22228cff, 0x00000000), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * 1.55f, paint)
            paint.shader = RadialGradient(cx - radius * .25f, cy - radius * .3f, radius * 1.3f, intArrayOf(0xffb5f7ff.toInt(), 0xff28bce9.toInt(), 0xff07508e.toInt(), 0xff03152e.toInt()), floatArrayOf(0f, .25f, .68f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * (1f + 0.018f * sin(phase.toDouble()).toFloat()), paint)
            paint.shader = null; paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = cyan
            canvas.drawCircle(cx, cy, radius * 1.18f, paint)
            paint.strokeWidth = 1f; paint.alpha = 150
            canvas.save(); canvas.rotate(phase * 35f, cx, cy); canvas.drawOval(cx-radius*1.42f, cy-radius*.38f, cx+radius*1.42f, cy+radius*.38f, paint); canvas.restore()
            paint.style = Paint.Style.FILL; paint.alpha = 255
            postInvalidateDelayed(40)
        }
    }
}
