package com.aegisnexus.app

/** Camada de estilo conversacional local; não requer rede nem chave de API. */
object AegisPersonality {
    fun reply(input: String, memories: List<String>): String {
        val text = input.trim()
        val lower = text.lowercase()
        return when {
            lower.matches(Regex("^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)[.! ]*$")) ->
                "Olá. Aegis Nexus online. Estou aqui para ajudar com calma, clareza e lógica. O que vamos resolver?"
            lower.contains("quem é você") || lower.contains("quem e voce") || lower.contains("o que é aegis") ->
                "Sou a Aegis Nexus, seu assistente pessoal. Posso conversar, ajudar a organizar ideias e guardar informações que você pedir para lembrar."
            lower.contains("como você está") || lower.contains("como voce esta") ->
                "Estou operacional e pronta para ajudar. Vamos direto ao que importa."
            lower.contains("projeto") && (lower.contains("aegis") || lower.contains("nexus")) ->
                "O Aegis Nexus é nosso projeto de assistente pessoal para Android. A proposta é preservar o que já funciona e acrescentar recursos em módulos separados."
            else -> {
                val contextHint = if (memories.isNotEmpty()) " Tenho algumas informações que você me autorizou a guardar, se forem úteis para esta conversa." else " Se quiser, você pode me pedir para guardar uma informação usando ‘lembre que…’."
                "Entendi. Vou tratar isso com atenção e organizar o raciocínio passo a passo. Para responder com precisão, preciso considerar o contexto e o objetivo do que você disse.$contextHint"
            }
        }
    }
}
